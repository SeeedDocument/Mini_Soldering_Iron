/********************* (C) COPYRIGHT 2017 e-Design Co.,Ltd. ********************
File Name :      own_sprintf.h
Version :        TS100 APP 2.18   
Description:
Author :         Ning
Data:            2017/11/06

2015/07/07   ͳһ����;
*******************************************************************************/



char * __own_itoa(int num,char *str);
char * own_sprintf(char* dest,const char*cntrl_string, ...);
